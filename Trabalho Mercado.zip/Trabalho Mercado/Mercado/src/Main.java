import model.*;
import controller.*;
import view.MenuPrincipal;

public class Main {
    public static void main(String[] args) {

        Estoque estoque = new Estoque();


        Categoria alimentos = new Categoria(1, "Alimentos", "Setor Alimentício");
        Categoria limpeza = new Categoria(2, "Limpeza", "Setor Químico/Limpeza");
        Categoria eletronicos = new Categoria(3, "Eletrônicos", "Setor Tecnológico");

        estoque.cadastrarProduto(new ProdutoAlimento(101, "Arroz Branco", 25.00, 30, alimentos, "25/12/2026"));
        estoque.cadastrarProduto(new ProdutoLimpeza(102, "Detergente Neutro", 3.50, 60, limpeza, "Cozinha"));
        estoque.cadastrarProduto(new ProdutoEletronico(103, "Fone Bluetooth", 80.00, 15, eletronicos, 12));


        ClienteController clienteController = new ClienteController();
        Cliente clienteExemplo = new Cliente(1, "Rodrigo Bez", "123.456.789-00");
        clienteController.cadastrarCliente(clienteExemplo);

        ProdutoController produtoController = new ProdutoController(estoque);
        PedidoController pedidoController = new PedidoController();
        ArquivoController arquivoController = new ArquivoController();


        MenuPrincipal sistema = new MenuPrincipal(
                estoque,
                produtoController,
                clienteController,
                pedidoController,
                arquivoController
        );

        // Executa o loop do Menu
        sistema.exibirMenu();
    }
}
