package model;

public class ItemPedido {
    private Produto produto;
    private int quantidade;

    public ItemPedido(Produto produto, int quantidade) {
        this.produto = produto;
        this.quantidade = quantidade;
    }

    public Produto getProduto() { return produto; }
    public int getQuantidade() { return quantidade; }

    // CORRIGIDO: Alterado getPreco() para calcularPrecoFinal() para respeitar as regras da Pessoa 1
    public double getSubtotal() {
        return produto.calcularPrecoFinal() * quantidade;
    }
}
