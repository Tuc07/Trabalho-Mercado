package view;

import controller.PagamentoController;
import java.util.Scanner;

public class PagamentoView {
    private PagamentoController pagamentoCtrl = new PagamentoController();
    private Scanner scanner = new Scanner(System.in);

    public boolean exibirTelaPagamento(double totalVenda) {
        System.out.println("\n--- CAIXA: PAGAMENTO ---");
        System.out.printf("Valor Total: R$ %.2f\n", totalVenda);
        System.out.println("1 - PIX");
        System.out.println("2 - Cartão de Crédito/Débito");
        System.out.print("Selecione o método: ");
        int op = scanner.nextInt();
        return pagamentoCtrl.efetuarPagamento(totalVenda, op);
    }
}
