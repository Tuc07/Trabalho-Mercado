package controller;

import model.*;

public class PagamentoController {
    private Pagamento pagamento;

    public boolean efetuarPagamento(double valor, int opcao) {
        if (opcao == 1) {
            pagamento = new PagamentoPix(valor);
        } else if (opcao == 2) {
            pagamento = new PagamentoCartao(valor);
        } else {
            System.out.println("Método de pagamento inválido!");
            return false;
        }
        pagamento.processarPagamento();
        return pagamento.isConfirmado();
    }
}
