package util;

import java.io.*;
import java.util.List;

public class ArquivoUtil {
    public static void salvarDados(String nomeArquivo, List<String> linhas) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nomeArquivo))) {
            for (String linha : linhas) {
                writer.write(linha);
                writer.newLine();
            }
        }
    }
}
