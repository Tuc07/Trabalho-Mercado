package interfaces;

public interface Vendavel {
    double getValorTotal();
}
