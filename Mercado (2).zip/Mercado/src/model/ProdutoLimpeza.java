package model;

public class ProdutoLimpeza extends Produto {
    private String tipoUso;

    public ProdutoLimpeza(int codigo, String nome, double preco, int quantidade, Categoria categoria, String tipoUso) {
        super(codigo, nome, preco, quantidade, categoria);
        this.tipoUso = tipoUso;
    }

    @Override
    public double calcularPrecoFinal() { return getPreco() * 1.03; }

    @Override
    public void exibirDados() {
        super.exibirDados();
        System.out.println("Tipo de uso: " + tipoUso);
        System.out.println("Tipo: Produto de Limpeza");
        System.out.println("-----------------------------");
    }

    public String getTipoUso() { return tipoUso; }
    public void setTipoUso(String tipoUso) { this.tipoUso = tipoUso; }
}
