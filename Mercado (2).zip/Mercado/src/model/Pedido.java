package model;

import interfaces.Vendavel;
import java.util.ArrayList;

public class Pedido implements Vendavel {
    private int numeroPedido;
    private Cliente cliente;
    private ArrayList<ItemPedido> itens;

    public Pedido(int numeroPedido, Cliente cliente) {
        this.numeroPedido = numeroPedido;
        this.cliente = cliente;
        this.itens = new ArrayList<>();
        cliente.adicionarPedido(this);
    }

    public void adicionarItem(ItemPedido item) {
        itens.add(item);
    }

    public int getNumeroPedido() { return numeroPedido; }
    public Cliente getCliente() { return cliente; }
    public ArrayList<ItemPedido> getItens() { return itens; }

    public double calcularTotal() {
        double total = 0;
        for (ItemPedido item : itens) {
            total += item.getSubtotal();
        }
        return total;
    }

    @Override
    public double getValorTotal() {
        return calcularTotal();
    }

    @Override
    public String toString() {
        return "Pedido Nº " + numeroPedido + " | Cliente: " + cliente.getNome() + " | Total: R$ " + calcularTotal();
    }
}
