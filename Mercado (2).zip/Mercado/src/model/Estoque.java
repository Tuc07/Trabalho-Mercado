package model;

import java.util.ArrayList;

public class Estoque {
    private ArrayList<Produto> produtos;

    public Estoque() {
        produtos = new ArrayList<>();
    }

    public void cadastrarProduto(Produto produto) {
        produtos.add(produto);
        System.out.println("Produto cadastrado com sucesso!");
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }

    public void listarProdutos() {
        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado no estoque.");
        } else {
            System.out.println("===== LISTA DE PRODUTOS =====");
            for (Produto produto : produtos) {
                produto.exibirDados();
            }
        }
    }

    public Produto buscarProdutoPorCodigo(int codigo) {
        for (Produto produto : produtos) {
            if (produto.getCodigo() == codigo) {
                return produto;
            }
        }
        return null;
    }

    public void editarProduto(int codigo, String novoNome, double novoPreco, int novaQuantidade) {
        Produto produto = buscarProdutoPorCodigo(codigo);
        if (produto != null) {
            produto.setNome(novoNome);
            produto.setPreco(novoPreco);
            produto.setQuantidade(novaQuantidade);
            System.out.println("Produto editado com sucesso!");
        } else {
            System.out.println("Produto não encontrado.");
        }
    }

    public void excluirProduto(int codigo) {
        Produto produto = buscarProdutoPorCodigo(codigo);
        if (produto != null) {
            produtos.remove(produto);
            System.out.println("Produto excluído com sucesso!");
        } else {
            System.out.println("Produto não encontrado.");
        }
    }

    public void adicionarQuantidade(int codigo, int quantidade) {
        Produto produto = buscarProdutoPorCodigo(codigo);
        if (produto != null) {
            int novaQuantidade = produto.getQuantidade() + quantidade;
            produto.setQuantidade(novaQuantidade);
            System.out.println("Quantidade adicionada ao estoque.");
        } else {
            System.out.println("Produto não encontrado.");
        }
    }

    public void removerQuantidade(int codigo, int quantidade) {
        Produto produto = buscarProdutoPorCodigo(codigo);
        if (produto != null) {
            if (produto.getQuantidade() >= quantidade) {
                int novaQuantidade = produto.getQuantidade() - quantidade;
                produto.setQuantidade(novaQuantidade);
                System.out.println("Quantidade removida do estoque.");
            } else {
                System.out.println("Quantidade insuficiente no estoque.");
            }
        } else {
            System.out.println("Produto não encontrado.");
        }
    }
}
