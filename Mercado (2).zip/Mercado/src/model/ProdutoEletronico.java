package model;

public class ProdutoEletronico extends Produto {
    private int garantiaMeses;

    public ProdutoEletronico(int codigo, String nome, double preco, int quantidade, Categoria categoria, int garantiaMeses) {
        super(codigo, nome, preco, quantidade, categoria);
        this.garantiaMeses = garantiaMeses;
    }

    @Override
    public double calcularPrecoFinal() { return getPreco() * 1.15; }

    @Override
    public void exibirDados() {
        super.exibirDados();
        System.out.println("Garantia: " + garantiaMeses + " meses");
        System.out.println("Tipo: Eletrônico");
        System.out.println("-----------------------------");
    }

    public int getGarantiaMeses() { return garantiaMeses; }
    public void setGarantiaMeses(int garantiaMeses) { this.garantiaMeses = garantiaMeses; }
}
