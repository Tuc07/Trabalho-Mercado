package model;

public abstract class Produto {
    private int codigo;
    private String nome;
    private double preco;
    private int quantidade;
    private Categoria categoria;

    public Produto(int codigo, String nome, double preco, int quantidade, Categoria categoria) {
        this.codigo = codigo;
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
        this.categoria = categoria;
    }

    public abstract double calcularPrecoFinal();

    public void exibirDados() {
        System.out.println("Código: " + codigo);
        System.out.println("Nome: " + nome);
        System.out.println("Preço base: R$ " + preco);
        System.out.println("Preço final: R$ " + calcularPrecoFinal());
        System.out.println("Quantidade em estoque: " + quantidade);
        System.out.println("Categoria: " + categoria.getNome());
    }

    public int getCodigo() { return codigo; }
    public String getNome() { return nome; }
    public double getPreco() { return preco; }
    public int getQuantidade() { return quantidade; }
    public Categoria getCategoria() { return categoria; }
    public void setCodigo(int codigo) { this.codigo = codigo; }
    public void setNome(String nome) { this.nome = nome; }
    public void setPreco(double preco) { this.preco = preco; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }
}