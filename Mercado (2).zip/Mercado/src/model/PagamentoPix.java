package model;

public class PagamentoPix extends Pagamento {
    public PagamentoPix(double valor) { super(valor); }

    @Override
    public void processarPagamento() {
        this.confirmado = true;
        System.out.println("[PIX] QR Code gerado de R$ " + valor + ". Pago com sucesso!");
    }
}