package model;

public class ProdutoAlimento extends Produto {
    private String dataValidade;

    public ProdutoAlimento(int codigo, String nome, double preco, int quantidade, Categoria categoria, String dataValidade) {
        super(codigo, nome, preco, quantidade, categoria);
        this.dataValidade = dataValidade;
    }

    @Override
    public double calcularPrecoFinal() { return getPreco() * 1.05; }

    @Override
    public void exibirDados() {
        super.exibirDados();
        System.out.println("Data de validade: " + dataValidade);
        System.out.println("Tipo: Alimento");
        System.out.println("-----------------------------");
    }

    public String getDataValidade() { return dataValidade; }
    public void setDataValidade(String dataValidade) { this.dataValidade = dataValidade; }
}
