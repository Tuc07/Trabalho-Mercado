package model;

public abstract class Pagamento {
    protected double valor;
    protected boolean confirmado;

    public Pagamento(double valor) {
        this.valor = valor;
        this.confirmado = false;
    }

    public abstract void processarPagamento();
    public boolean isConfirmado() { return confirmado; }
}