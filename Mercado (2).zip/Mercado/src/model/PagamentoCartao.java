package model;

public class PagamentoCartao extends Pagamento {
    public PagamentoCartao(double valor) { super(valor); }

    @Override
    public void processarPagamento() {
        this.confirmado = true;
        System.out.println("[CARTÃO] Transação de R$ " + valor + " Aprovada!");
    }
}