package model;

import java.util.ArrayList;

public class Carrinho {
    private ArrayList<ItemPedido> itens;

    public Carrinho() {
        itens = new ArrayList<>();
    }

    public void adicionarProduto(Produto produto, int quantidade) {
        ItemPedido item = new ItemPedido(produto, quantidade);
        itens.add(item);
    }

    public ArrayList<ItemPedido> getItens() { return itens; }

    public double calcularTotal() {
        double total = 0;
        for (ItemPedido item : itens) {
            total += item.getSubtotal();
        }
        return total;
    }

    public void limparCarrinho() {
        itens.clear();
    }
}
