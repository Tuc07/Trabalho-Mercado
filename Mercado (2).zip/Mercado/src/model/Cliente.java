package model;

import java.util.ArrayList;

public class Cliente extends Pessoa {
    private ArrayList<Pedido> pedidos;

    public Cliente(int id, String nome, String cpf) {
        super(id, nome, cpf);
        this.pedidos = new ArrayList<>();
    }

    public void adicionarPedido(Pedido pedido) {
        pedidos.add(pedido);
    }

    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }

    @Override
    public String toString() {
        return "Cliente: " + getNome();
    }
}
