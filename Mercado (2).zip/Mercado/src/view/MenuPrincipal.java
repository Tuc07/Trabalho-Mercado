package view;

import controller.*;
import model.*;
import java.util.Scanner;

public class MenuPrincipal {
    private Scanner scanner = new Scanner(System.in);
    private Estoque estoque;
    private ProdutoController produtoCtrl;
    private ClienteController clienteCtrl;
    private PedidoController pedidoCtrl;
    private ArquivoController arquivoCtrl;
    private PagamentoView pagamentoView;

    public MenuPrincipal(Estoque estoque, ProdutoController pCtrl, ClienteController cCtrl, PedidoController pdCtrl, ArquivoController aCtrl) {
        this.estoque = estoque;
        this.produtoCtrl = pCtrl;
        this.clienteCtrl = cCtrl;
        this.pedidoCtrl = pdCtrl;
        this.arquivoCtrl = aCtrl;
        this.pagamentoView = new PagamentoView();
    }

    public void exibirMenu() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n===== MERCADO INTEGRADO (MVC) =====");
            System.out.println("1 - Visualizar Estoque Completo ");
            System.out.println("2 - Buscar Informações de Cliente ");
            System.out.println("3 - Passar uma Venda no Caixa ");
            System.out.println("4 - Exportar Relatório de Estoque ");
            System.out.println("5 - Cadastrar Novo Cliente ");
            System.out.println("6 - Cadastrar Novo Produto ");
            System.out.println("7 - Excluir Produto do Estoque ");
            System.out.println("0 - Sair do Sistema");
            System.out.print("Opção: ");

            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    produtoCtrl.listar();
                    break;
                case 2:
                    System.out.print("Informe o ID do Cliente: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    Cliente c = clienteCtrl.buscarClientePorId(id);
                    if (c != null) {
                        System.out.println("Dados do Registro -> " + c + " | CPF: " + c.getCpf());
                    } else {
                        System.out.println("Erro: Cliente não localizado.");
                    }
                    break;
                case 3:
                    System.out.print("Informe o ID do Cliente da compra: ");
                    int idCli = scanner.nextInt();
                    scanner.nextLine();
                    Cliente comprador = clienteCtrl.buscarClientePorId(idCli);

                    if (comprador != null) {
                        pedidoCtrl.iniciarNovoPedido(comprador);
                        System.out.print("Código do produto que deseja adicionar: ");
                        int cod = scanner.nextInt();
                        scanner.nextLine();
                        Produto p = produtoCtrl.buscar(cod);

                        if (p != null) {
                            System.out.print("Quantidade desejada: ");
                            int qtd = scanner.nextInt();
                            scanner.nextLine();
                            pedidoCtrl.adicionarItemAoPedido(p, qtd);

                            Pedido atual = pedidoCtrl.getPedidoAtual();
                            if (atual != null && atual.calcularTotal() > 0) {
                                boolean confirmado = pagamentoView.exibirTelaPagamento(atual);
                                if (confirmado) {
                                    System.out.println("VENDA CONCLUÍDA! Cupom fiscal impresso.");
                                    pedidoCtrl.fecharPedido();
                                }
                            }
                        } else {
                            System.out.println("Erro: Produto inexistente.");
                        }
                    } else {
                        System.out.println("Erro: Cliente precisa estar cadastrado para comprar.");
                    }
                    break;
                case 4:
                    arquivoCtrl.exportarEstoque(estoque.getProdutos());
                    break;
                case 5:
                    System.out.println("\n--- NOVO CADASTRO DE CLIENTE ---");
                    System.out.print("Informe o ID numérico para o cliente: ");
                    int novoId = scanner.nextInt();
                    scanner.nextLine();

                    if (clienteCtrl.buscarClientePorId(novoId) != null) {
                        System.out.println("Erro: Já existe um cliente com este ID!");
                        break;
                    }

                    System.out.print("Informe o Nome Completo: ");
                    String nomeStr = scanner.nextLine();
                    System.out.print("Informe o CPF: ");
                    String cpfStr = scanner.nextLine();

                    clienteCtrl.cadastrarCliente(new Cliente(novoId, nomeStr, cpfStr));
                    System.out.println("Sucesso: Cliente '" + nomeStr + "' cadastrado!");
                    break;

                case 6:
                    System.out.println("\n--- NOVO CADASTRO DE PRODUTO ---");
                    System.out.print("Informe o Código numérico do produto: ");
                    int codProd = scanner.nextInt();
                    scanner.nextLine();

                    if (produtoCtrl.buscar(codProd) != null) {
                        System.out.println("Erro: Já existe um produto com este código!");
                        break;
                    }

                    System.out.print("Nome do Produto: ");
                    String nomeProd = scanner.nextLine();
                    System.out.print("Preço Base: R$ ");
                    double precoProd = scanner.nextDouble();
                    System.out.print("Quantidade Inicial em Estoque: ");
                    int qtdProd = scanner.nextInt();
                    System.out.println("Selecione o Tipo de Produto:");
                    System.out.println("1 - Alimento");
                    System.out.println("2 - Produto de Limpeza");
                    System.out.println("3 - Eletrônico");
                    System.out.print("Tipo: ");
                    int tipoProd = scanner.nextInt();
                    scanner.nextLine();

                    Produto novoProduto = null;

                    if (tipoProd == 1) {
                        System.out.print("Data de Validade (dd/mm/aaaa): ");
                        String validade = scanner.nextLine();
                        Categoria catAlimento = new Categoria(1, "Alimentos", "Setor Alimentício");
                        novoProduto = new ProdutoAlimento(codProd, nomeProd, precoProd, qtdProd, catAlimento, validade);
                    } else if (tipoProd == 2) {
                        System.out.print("Tipo de Uso (ex: Cozinha, Banheiro): ");
                        String tipoUso = scanner.nextLine();
                        Categoria catLimpeza = new Categoria(2, "Limpeza", "Setor Químico/Limpeza");
                        novoProduto = new ProdutoLimpeza(codProd, nomeProd, precoProd, qtdProd, catLimpeza, tipoUso);
                    } else if (tipoProd == 3) {
                        System.out.print("Meses de Garantia de Fábrica: ");
                        int garantia = scanner.nextInt();
                        scanner.nextLine();
                        Categoria catEletronicos = new Categoria(3, "Eletrônicos", "Setor Tecnológico");
                        novoProduto = new ProdutoEletronico(codProd, nomeProd, precoProd, qtdProd, catEletronicos, garantia);
                    } else {
                        System.out.println("Erro: Tipo de produto inválido. Cadastro cancelado.");
                        break;
                    }

                    produtoCtrl.cadastrar(novoProduto);
                    break;

                case 7:
                    System.out.println("\n--- EXCLUSÃO DE PRODUTO ---");
                    System.out.print("Informe o Código do produto que deseja remover: ");
                    int codExcluir = scanner.nextInt();
                    scanner.nextLine();

                    produtoCtrl.excluir(codExcluir);
                    break;

                case 0:
                    System.out.println("Encerrando execução.");
                    break;
                default:
                    System.out.println("Opção incorreta.");
            }
        }
    }
}