package controller;

import util.ArquivoUtil;
import model.Produto;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ArquivoController {
    private final String CAMINHO_BKP = "backup_estoque.txt";

    public void exportarEstoque(ArrayList<Produto> listaEstoque) {
        try {
            List<String> linhas = new ArrayList<>();
            for (Produto p : listaEstoque) {
                linhas.add(p.getCodigo() + ";" + p.getNome() + ";" + p.calcularPrecoFinal() + ";" + p.getQuantidade());
            }
            ArquivoUtil.salvarDados(CAMINHO_BKP, linhas);
            System.out.println("Sucesso: Backup salvo em '" + CAMINHO_BKP + "'");
        } catch (IOException e) {
            System.err.println("Falha ao salvar arquivo: " + e.getMessage());
        }
    }
}