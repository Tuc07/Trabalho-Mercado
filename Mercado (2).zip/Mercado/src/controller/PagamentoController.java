package controller;

import model.*;
import interfaces.Vendavel;

public class PagamentoController {
    private Pagamento pagamento;

    public boolean efetuarPagamento(Vendavel itemVendavel, int opcao) {

        double valor = itemVendavel.getValorTotal();

        if (opcao == 1) {
            pagamento = new PagamentoPix(valor);
        } else if (opcao == 2) {
            pagamento = new PagamentoCartao(valor);
        } else {
            System.out.println("Método de pagamento inválido!");
            return false;
        }
        pagamento.processarPagamento();
        return pagamento.isConfirmado();
    }
}
