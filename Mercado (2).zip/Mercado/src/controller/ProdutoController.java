package controller;

import model.Estoque;
import model.Produto;

public class ProdutoController {
    private Estoque estoque;

    public ProdutoController(Estoque estoque) { this.estoque = estoque; }
    public void cadastrar(Produto p) { estoque.cadastrarProduto(p); }
    public void listar() { estoque.listarProdutos(); }
    public Produto buscar(int cod) { return estoque.buscarProdutoPorCodigo(cod); }
    public void excluir(int cod) { estoque.excluirProduto(cod); }
}