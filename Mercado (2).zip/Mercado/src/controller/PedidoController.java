package controller;

import model.*;

public class PedidoController {
    private Pedido pedidoAtual;
    private int geradorIdPedido = 1;

    public void iniciarNovoPedido(Cliente c) {
        pedidoAtual = new Pedido(geradorIdPedido++, c);
        System.out.println("Caixa: Pedido número " + pedidoAtual.getNumeroPedido() + " iniciado para " + c.getNome());
    }

    public void adicionarItemAoPedido(Produto p, int qtd) {
        if (pedidoAtual == null) {
            System.out.println("Nenhum pedido ativo no caixa!");
            return;
        }
        if (p.getQuantidade() < qtd) {
            System.out.println("Estoque insuficiente para o produto: " + p.getNome());
            return;
        }

        p.setQuantidade(p.getQuantidade() - qtd);
        pedidoAtual.adicionarItem(new ItemPedido(p, qtd));
        System.out.println(qtd + "x '" + p.getNome() + "' adicionado ao carrinho.");
    }

    public Pedido getPedidoAtual() { return pedidoAtual; }
    public void fecharPedido() { this.pedidoAtual = null; }
}
